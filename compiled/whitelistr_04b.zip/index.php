<!-- whitelistrBETA - whitelist.php - by luaduck 2011 - for closed distribution only -->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Whitelistr BETA</title>
<link type="text/css" rel="stylesheet" href="includes/style.css" />
<link rel="shortcut icon" href="favicon.ico" />
<script type="text/javascript" src="includes/jquery.js"></script> <!-- Init jquery -->
<script type="text/javascript" src="includes/scripting.js"></script>
</head>
<body>
<h1 id="logo"></h1>
<form action="whitelist.php" method="post">

<p>Invitation key: <input type="text" name="key" /><br />
Minecraft username: <input type="text" name="username" /><br />
E-mail for newsletter (optional): <input type="text" name="email" /></p>

<p><input type="submit" value="Add me!"/></p>
</form>
<a href="admin/index.php">Admin Control Panel</a>
</body>

</html>
