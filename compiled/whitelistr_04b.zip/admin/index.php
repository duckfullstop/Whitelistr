<?php
error_reporting(E_ALL);
include("auth.php");
showForm();
?>